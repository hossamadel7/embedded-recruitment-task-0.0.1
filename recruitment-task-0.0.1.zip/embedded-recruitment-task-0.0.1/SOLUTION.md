# Solution

Here you can document all bugs and design flaws.